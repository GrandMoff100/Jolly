print("Hello, world! (from a zipped module)")
