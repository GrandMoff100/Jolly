print("Inside zipped/hello/__init__.py, importing .hello")

from . import hello

print("Inside zipped/hello/__init__.py (after importing .hello)")
