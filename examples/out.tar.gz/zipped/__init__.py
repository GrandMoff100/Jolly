print("Inside zipped/__init__.py")
